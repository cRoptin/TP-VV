package example;


public class B  {


    public void mth1(int i) {

		vv.spoon.logger.LogWriter.count("void mth1(int)",2);
        System.out.println("B.mth1(int i)");

        C c = new C(i);
        int result = c.mth1();

        System.out.println("result = " + result);
    }

    public void mth2() {

		vv.spoon.logger.LogWriter.count("void mth2()",1);
        System.out.println("B.mth2()");
    }

}
