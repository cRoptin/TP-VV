package vv.spoon.processor;

import java.util.HashMap;
import java.util.Map;

import spoon.processing.AbstractProcessor;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.cu.CompilationUnit;
import spoon.reflect.cu.SourceCodeFragment;
import spoon.reflect.cu.SourcePosition;
import spoon.reflect.reference.CtExecutableReference;

public class TreeProcessor extends AbstractProcessor<CtInvocation> {
		
		@Override
	    public boolean isToBeProcessed(CtInvocation candidate) {
	        try {
	            return true;
	        } catch (Exception e) {
	            return true;
	        }
	    }
	    
	  //check if executable is java.io.PrintStream.println(...) or java.io.PrintStream.print(...) method
	    protected boolean isPrint(CtExecutableReference executable) {
	        String toString = executable.toString();
	        return toString.startsWith("public ");
	    }

		@Override
		public void process(CtInvocation element) {
			SourcePosition sp = element.getPosition();
	        CompilationUnit compileUnit = sp.getCompilationUnit();

	        //add /** before the invocation
	        /*SourceCodeFragment before = new SourceCodeFragment(compileUnit.beginOfLineIndex(sp.getSourceStart()), "/**", 0);
	        compileUnit.addSourceCodeFragment(before);*/

	        //add **/ vv.spoon.logger.LogWriter.out( argument, newline, error); after the invocation
	        Object argument = element.getSignature();
	        
	        String snippet = "\n\t\tvv.spoon.logger.LogWriter.count(\" | " + argument + ");\r\n";

	        SourceCodeFragment after = new SourceCodeFragment(compileUnit.nextLineIndex(sp.getSourceEnd()), snippet, 0);
	        compileUnit.addSourceCodeFragment(after);
			
		}
}
