package vv.spoon.processor;

import java.util.HashMap;
import java.util.Map;

import spoon.processing.AbstractProcessor;
import spoon.reflect.code.CtExpression;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.cu.CompilationUnit;
import spoon.reflect.cu.SourceCodeFragment;
import spoon.reflect.cu.SourcePosition;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.reference.CtExecutableReference;

public class CountProcessor extends AbstractProcessor<CtMethod> {

	private static Map<Object, Integer> mapCount;
	
	@Override
    public boolean isToBeProcessed(CtMethod candidate) {
        try {
            return true;
        } catch (Exception e) {
            return true;
        }
    }
    
  //check if executable is java.io.PrintStream.println(...) or java.io.PrintStream.print(...) method
    protected boolean isPrint(CtExecutableReference executable) {
        String toString = executable.toString();
        return toString.startsWith("public ");
    }

	@Override
	public void process(CtMethod element) {
		SourcePosition sp = element.getPosition();
        CompilationUnit compileUnit = sp.getCompilationUnit();

        //add /** before the invocation
        /*SourceCodeFragment before = new SourceCodeFragment(compileUnit.beginOfLineIndex(sp.getSourceStart()), "/**", 0);
        compileUnit.addSourceCodeFragment(before);*/

        //add **/ vv.spoon.logger.LogWriter.out( argument, newline, error); after the invocation
        Object argument = element.getSignature();
        
        if (mapCount == null) {
        	mapCount = new HashMap<Object, Integer>();
        }
        int iTmpCount = 0;
        if (mapCount.get(argument) != null) {
        	iTmpCount = mapCount.get(argument);   
        }
        mapCount.put(argument, (iTmpCount + 1));
        
        String snippet = "\n\t\tvv.spoon.logger.LogWriter.count(\"" + argument
                + "\"," + mapCount.get(argument) + ");\n";

        SourceCodeFragment after = new SourceCodeFragment(compileUnit.nextLineIndex(sp.getSourceEnd()), snippet, 0);
        compileUnit.addSourceCodeFragment(after);
		
	}

}
