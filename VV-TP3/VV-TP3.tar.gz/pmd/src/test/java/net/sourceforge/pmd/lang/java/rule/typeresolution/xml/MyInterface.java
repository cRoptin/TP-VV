package net.sourceforge.pmd.lang.java.rule.typeresolution.xml;


/**
 * 	Warning, this class ARE not useless. 
 * 	It is used by the some of regression
 * 	tests.
 */
public interface MyInterface extends Cloneable {

}
