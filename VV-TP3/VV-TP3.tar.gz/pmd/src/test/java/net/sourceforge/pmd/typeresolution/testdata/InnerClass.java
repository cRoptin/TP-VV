package net.sourceforge.pmd.typeresolution.testdata;

public class InnerClass {
	public class TheInnerClass {
	}

	public void foo(TheInnerClass arg) {
	}
}
