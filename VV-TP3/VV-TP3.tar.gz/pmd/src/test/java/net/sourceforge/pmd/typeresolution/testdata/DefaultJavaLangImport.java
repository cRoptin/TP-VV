package net.sourceforge.pmd.typeresolution.testdata;

public class DefaultJavaLangImport {
    @Override
    public String toString() {
        return "foo";
    }
}
