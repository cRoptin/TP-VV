package net.sourceforge.pmd.lang.java.rule.typeresolution.xml;

import org.junit.Ignore;
import junit.framework.TestCase;

/**
 * 	Warning, this class IS NOT useless. 
 * 	It is used by the some regression tests.
 * 
 *      See file: SignatureDeclareThrowsException.xml
 *      
 *      The file is already excluded from maven/surefire.
 */
@Ignore
public class MyTestCase extends TestCase {

}
