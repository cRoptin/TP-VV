package net.sourceforge.pmd.typeresolution.testdata;

import java.util.ArrayList;

public class ArrayListFound {
	ArrayList x;
}
