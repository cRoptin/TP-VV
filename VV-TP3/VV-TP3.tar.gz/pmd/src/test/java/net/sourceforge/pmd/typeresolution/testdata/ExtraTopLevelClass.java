package net.sourceforge.pmd.typeresolution.testdata;

public class ExtraTopLevelClass {
}

class TheExtraTopLevelClass {
}
