public class File2 {
    public void dup() {
        for (int j = 0; j < 10; j++) {
            System.out.println(j);
        }
    }
}