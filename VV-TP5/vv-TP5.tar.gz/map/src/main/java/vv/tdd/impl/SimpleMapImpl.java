package vv.tdd.impl;

import java.util.*;

public class SimpleMapImpl<K,V> implements Map<K,V> {

	List<K> loEntries = new ArrayList<K>();
	List<V> loValues = new ArrayList<V>();

    //@Override
    public int size() {
    	int iCount = 0;
    	if (loEntries != null) {
    		iCount = loEntries.size();
    	}
        return iCount;
    }

    //@Override
    public boolean isEmpty() {
    	boolean bEmpty = true;
    	if (loEntries != null && loEntries.size() > 0) {
    		bEmpty = false;
    	}
        return bEmpty;
    }

    //@Override
    public boolean containsKey(Object key) {
    	boolean bContain = false;
    	if (loEntries != null) {
    		for (K k : loEntries) {
    			if (k.equals(key)) {
    				bContain = true;
    			}
    		}
    	}
        return bContain;
    }

    //@Override
    public boolean containsValue(Object value) {
    	boolean bContain = false;
    	if (loValues != null) {
    		for (V v : loValues) {
    			if (v.equals(value)) {
    				bContain = true;
    			}
    		}
    	}
        return bContain;
    }

    //@Override
    @SuppressWarnings("unchecked")
	public V get(Object key) {
    	V oRes = null;
    	if (loEntries != null && loEntries.contains(key)) {
    		int iKeyIdx = getKeyIndex((K) key);
    		if (loValues != null && loValues.size() > iKeyIdx) {
    			oRes = loValues.get(iKeyIdx);
    		}
    	}
        return oRes;
    }

    //@Override
    public V put(K key, V value) {
    	V oPrevValue = null;
    	if (loEntries == null) {
    		loEntries = new ArrayList<K>();
    	}
    	if (loValues == null) {
			loValues = new ArrayList<V>();
		}
    	if (!loEntries.contains(key)) {
    		loEntries.add(key);
    		loValues.add(value);
    	} else {
    		int iKeyIdx = getKeyIndex((K) key);
    		
    		if (loValues.size() <= iKeyIdx) {
    			while (loValues.size() <= iKeyIdx) {
    				loValues.add(null);
    			}
    		}
    		oPrevValue = loValues.get(iKeyIdx);
    		loValues.set(iKeyIdx, value);
    	}
        return oPrevValue;
    }

    //@Override
    @SuppressWarnings("unchecked")
	public V remove(Object key) {
    	V oPrevValue = null;
    	if (loEntries != null && loEntries.contains(key)) {
    		int iKeyIdx = getKeyIndex((K) key);
    		if (loValues != null && loValues.get(iKeyIdx) != null) {
    			oPrevValue = loValues.get(iKeyIdx);
    			loValues.remove(oPrevValue);
    		}
    		loEntries.remove(key);
    	}
        return oPrevValue;
    }
    
    private int getKeyIndex(K poKey) {
    	int iKeyIdx = 0;
		for (int iIdx = 0; iIdx < loEntries.size(); iIdx++) {
			if (loEntries.get(iIdx).equals(poKey)) {
				iKeyIdx = iIdx;
			}
		}
		return iKeyIdx;
    }

    //@Override
    @SuppressWarnings("unchecked")
	public void putAll(Map<? extends K, ? extends V> m) {
    	Set<K> soKeys = (Set<K>) m.keySet();
    	
    	if (loEntries == null || loEntries.size() == 0) {
    		loEntries = new ArrayList<K>();
    		loValues = new ArrayList<V>();
    		for (K oKey : soKeys) {
    			loEntries.add(oKey);
    			loValues.add(m.get(oKey));
    		}
    	} else {
    		for (K oKey : soKeys) {
        		if (loEntries.contains(oKey)) {
        			int iKeyIdx = getKeyIndex(oKey);
        			if (loValues == null) {
        				loValues = new ArrayList<V>();
        			}
        			if (loValues.size() <= iKeyIdx) {
        				for (int iValIdx = loValues.size(); iValIdx <= iKeyIdx; iValIdx++) {
        					loValues.add(null);
        				}
        			}
        			loValues.set(iKeyIdx, m.get(oKey));
        		} else {
        			loEntries.add(oKey);
        			loValues.add(m.get(oKey));
        		}
        	}
    	}
    	
    }

    //@Override
    public void clear() {
    	loEntries = null;
    	loValues = null;
    }

    //@Override
    public Set<K> keySet() {
    	Set<K> soKeys = null;
    	if (loEntries != null) {
    		soKeys = new HashSet<K>();
    		for (K oEntry : loEntries) {
    			soKeys.add(oEntry);
    		}
    	}
        return soKeys;
    }

    //@Override
    public Collection<V> values() {
        return loValues;
    }

    //@Override
    public Set<Entry<K, V>> entrySet() {
    	Set<Entry<K, V>> seResult = null;
    	if (loEntries != null) {
    		seResult = new HashSet<Map.Entry<K,V>>();
    		for (int iEntry = 0; iEntry < loEntries.size(); iEntry++) {
    			if (loValues != null && loValues.get(iEntry) != null) {
    				Entry<K, V> oEntry = (Entry<K, V>) new AbstractMap.SimpleEntry<K, V>(loEntries.get(iEntry), loValues.get(iEntry));
    				seResult.add(oEntry);
    			} else {
    				Entry<K, V> oEmptyEntry = (Entry<K, V>) new AbstractMap.SimpleEntry<K, V>(loEntries.get(iEntry), null);
    				seResult.add(oEmptyEntry);
    			}
    		}
    	}
    	
        return seResult;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((loEntries == null) ? 0 : loEntries.hashCode());
		result = prime * result + ((loValues == null) ? 0 : loValues.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		SimpleMapImpl other = (SimpleMapImpl) obj;
		if (loEntries == null) {
			if (other.loEntries != null) {
				return false;
			}
		} else if (!loEntries.equals(other.loEntries)) {
			return false;
		}
		if (loValues == null) {
			if (other.loValues != null) {
				return false;
			}
		} else if (!loValues.equals(other.loValues)) {
			return false;
		}
		return true;
	}

}
