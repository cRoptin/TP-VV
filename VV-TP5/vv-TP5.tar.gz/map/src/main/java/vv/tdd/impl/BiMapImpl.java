package vv.tdd.impl;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Simon on 30/09/14.
 */
public class BiMapImpl<K,V> extends SimpleMapImpl<K,V> implements vv.tdd.BiMap<K,V> {

	List<K> loEntries = new ArrayList<K>();
	List<V> loValues = new ArrayList<V>();
	
    //@Override
    public K getByValue(Object value) {
    	int index = loValues.indexOf(value);
        if(index!= -1)
        {
            return loEntries.get(index);
        }
        else
        {
            return null;
        }
    }

    //@Override
    public K removeValue(Object value) {
    	int index = loValues.indexOf(value);
        if(index==-1) //si le key n'existe pas
        {
            return null;
        }
        else
        {
        	loValues.remove(index);
            K elt = loEntries.get(index);
            loEntries.remove(index);
            return elt;
        }
    }
}
